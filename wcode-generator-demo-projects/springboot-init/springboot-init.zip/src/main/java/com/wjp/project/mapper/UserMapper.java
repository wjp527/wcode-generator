package com.wjp.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wjp.project.model.entity.User;

/**
 * @Entity com.wjp.project.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




